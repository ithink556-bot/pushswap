/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sortstart.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 16:37:41 by hasdia            #+#    #+#             */
/*   Updated: 2025/10/21 16:44:33 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sorttwo(t_stack *stack)
{
	if (stack->a[0] > stack->a[1])
		sa(stack);
}

void	sortthree(t_stack *stack)
{
	int	a;
	int	b;
	int	c;

	a = stack->a[0];
	b = stack->a[1];
	c = stack->a[2];
	if (a > b && b < c && a < c)
		sa(stack);
	else if (a > b && b > c)
	{
		sa(stack);
		rra(stack);
	}
	else if (a > b && b < c && a > c)
		ra(stack);
	else if (a < b && b > c && a < c)
	{
		sa(stack);
		ra(stack);
	}
	else if (a < b && b > c && a > c)
		rra(stack);
}

void	sortfour(t_stack *stack)
{
	int	posmin;

	posmin = findpositionofmin(stack->a, stack->size_a);
	rotatemintop(stack, posmin, stack->size_a);
	pa(stack);
	sortthree(stack);
	pb(stack);
}

void	sortfive(t_stack *stack)
{
	int	posmin;

	posmin = findpositionofmin(stack->a, stack->size_a);
	rotatemintop(stack, posmin, stack->size_a);
	pa(stack);
	posmin = findpositionofmin(stack->a, stack->size_a);
	rotatemintop(stack, posmin, stack->size_a);
	pa(stack);
	sortthree(stack);
	pb(stack);
	pb(stack);
}

void	sort(t_stack *stack)
{
	if (stack->size_a <= 1)
		return ;
	else if (stack->size_a == 2)
		sorttwo(stack);
	else if (stack->size_a == 3)
		sortthree(stack);
	else if (stack->size_a == 4)
		sortfour(stack);
	else if (stack->size_a == 5)
		sortfive(stack);
	else
		sortlarge(stack);
}
