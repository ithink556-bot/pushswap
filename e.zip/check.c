/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 16:38:16 by hasdia            #+#    #+#             */
/*   Updated: 2025/10/21 16:38:17 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	checkmaxmin(long nb, int sign, char c, int *bool)
{
	if (sign > 0 && nb > (INT_MAX - (c - '0')) / 10)
	{
		*bool = -1;
		return (1);
	}
	if (sign < 0 && nb < (INT_MIN + (c - '0')) / 10)
	{
		*bool = -1;
		return (1);
	}
	return (0);
}

int	ft_atoi(char *str, int *bool)
{
	long	i;
	long	nb;
	int		sign;

	sign = 1;
	i = 0;
	nb = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
		i++;
	if (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		if (checkmaxmin(nb, sign, str[i], bool))
			return (0);
		nb *= 10;
		nb += sign * (str[i] - '0');
		i++;
	}
	return (nb);
}
