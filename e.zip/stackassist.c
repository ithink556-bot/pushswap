/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stackassist.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 16:37:28 by hasdia            #+#    #+#             */
/*   Updated: 2025/10/21 16:37:30 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	getsize(char *str, int i)
{
	int	size;

	size = 0;
	if (str[i] == '+' || str[i] == '-')
	{
		size++;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		size++;
		i++;
	}
	return (size);
}

char	*getnb(char *str, int *i)
{
	char	*nb;
	int		size;
	int		j;

	if (!str || str[*i] == '\0')
		return (NULL);
	j = 0;
	size = 0;
	size = getsize(str, *i);
	if (size == 0)
		return (NULL);
	nb = malloc(sizeof(char) * (size + 1));
	if (!nb)
		return (NULL);
	while (j < size)
	{
		nb[j] = str[*i];
		(*i)++;
		j++;
	}
	nb[j] = '\0';
	return (nb);
}

int	*allocate(char *str, int *size)
{
	int	*array;

	*size = countnumbers(str);
	if (*size <= 0)
		return (NULL);
	array = malloc(sizeof(int) * (*size));
	if (!array)
		return (NULL);
	return (array);
}

int	*intializearray(char *str)
{
	int		i;
	int		j;
	int		size;
	int		*array;
	char	*temp;

	i = 0;
	j = 0;
	array = allocate(str, &size);
	if (!array || !size)
		return (NULL);
	while (str[i])
	{
		while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
			i++;
		if (str[i] == '\0')
			break ;
		temp = getnb(str, &i);
		if (!temp)
			return (free(array), NULL);
		array[j++] = ft_atoi(temp, &size);
		if (free(temp), size == -1)
			return (free(array), NULL);
	}
	return (array);
}

int	*intializearray2(char *argv[], int size)
{
	int		i;
	int		*array;
	int		flag;

	array = malloc(sizeof(int) * size);
	if (!array)
		return (NULL);
	i = 0;
	while (i < size)
	{
		flag = 0;
		if (check(argv[i + 1]))
			return (free(array), NULL);
		array[i] = ft_atoi(argv[i + 1], &flag);
		if (flag == -1)
			return (free(array), NULL);
		i++;
	}
	return (array);
}
