/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 18:55:02 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:05:25 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <unistd.h>
# include <stdlib.h>
# include <limits.h>
# include <stdio.h>

typedef struct s_stack
{
	int		*a;
	int		*b;
	int		size_a;
	int		size_b;
}	t_stack;

int		countnumbers(char *str);
int		*intializearray(char *str);
int		*intializearray2(char *argv[], int size);
int		ft_atoi(char *str, int *bool);
int		check(char *str);
void	swap(int *array, int size);
void	push(int *array1, int *array2, int *size1, int *size2);
void	rotate(int *array, int size);
void	reverse_rotate(int *array, int size);
void	sa(t_stack *stack);
void	sb(t_stack *stack);
void	ss(t_stack *stack);
void	pa(t_stack *stack);
void	pb(t_stack *stack);
void	ra(t_stack *stack);
void	rb(t_stack *stack);
void	rr(t_stack *stack);
void	rra(t_stack *stack);
void	rrb(t_stack *stack);
void	rrr(t_stack *stack);
void	sort(t_stack *stack);
int		findpositionofmin(int *array, int size);
void	rotatemintop(t_stack *stack, int pos, int size);

#endif