/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OperationsA.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 01:40:30 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:17:13 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sa(t_stack *stack)
{
	swap(stack->a, stack->size_a);
	write(1, "sa\n", 3);
}

void	pa(t_stack *stack)
{
	push(stack->b, stack->a, &stack->size_b, &stack->size_a);
	write(1, "pa\n", 3);
}

void	ra(t_stack *stack)
{
	rotate(stack->a, stack->size_a);
	write(1, "ra\n", 3);
}

void	rra(t_stack *stack)
{
	reverse_rotate(stack->a, stack->size_a);
	write(1, "rra\n", 4);
}
