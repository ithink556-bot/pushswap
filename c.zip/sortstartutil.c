/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sortstartutil.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 01:58:34 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:05:07 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	findpositionofmin(int *array, int size)
{
	int	min;
	int	pos;
	int	i;

	min = array[0];
	pos = 0;
	i = 1;
	while (i < size)
	{
		if (array[i] < min)
		{
			min = array[i];
			pos = i;
		}
		i++;
	}
	return (pos);
}

void	rotatemintop(t_stack *stack, int pos, int size)
{
	if (pos <= size / 2)
	{
		while (pos > 0)
		{
			ra(stack);
			pos--;
		}
	}
	else
	{
		while (pos < size)
		{
			rra(stack);
			pos++;
		}
	}
}
