/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   CoreOperations.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 01:09:22 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 01:28:43 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	swap(int *array, int size)
{
	int	temp;

	if (size < 2)
		return ;
	temp = array[0];
	array[0] = array[1];
	array[1] = temp;
}

void	push(int *array1, int *array2, int *size1, int *size2)
{
	int	temp;
	int	i;

	if (*size1 == 0)
		return ;
	i = 0;
	temp = array1[0];
	while (i < *size1 - 1)
	{
		array1[i] = array1[i + 1];
		i++;
	}
	*size1 = *size1 - 1;
	*size2 = *size2 + 1;
	i = *size2;
	while (i > 0)
	{
		array2[i] = array2[i - 1];
		i--;
	}
	array2[0] = temp;
}

void	rotate(int *array, int size)
{
	int	temp;
	int	i;

	if (size < 2)
		return ;
	i = 0;
	temp = array[0];
	while (i < size - 1)
	{
		array[i] = array[i + 1];
		i++;
	}
	array[size - 1] = temp;
}

void	reverse_rotate(int *array, int size)
{
	int	temp;
	int	i;

	if (size < 2)
		return ;
	i = 0;
	temp = array[size - 1];
	i = size - 1;
	while (i > 0)
	{
		array[i] = array[i - 1];
		i--;
	}
	array[0] = temp;
}
