/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 18:58:59 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:15:45 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	caseone(char *str)
{
	t_stack	*stack;
	int		size;

	size = 0;
	size = countnumbers(str);
	if (size <= 0)
		return (1);
	stack = malloc(sizeof(t_stack) * 1);
	if (!stack)
		return (1);
	stack->a = intializearray(str);
	if (!stack->a)
		return (free(stack), 1);
	stack->b = malloc(sizeof(int) * size);
	if (!stack->b)
		return (free(stack->a), free(stack), 1);
	stack->size_a = size;
	stack->size_b = 0;
	sort(stack);
	return (free(stack->a), free(stack->b), free(stack), 0);
}

int	casetwo(char *argv[], int argc)
{
	t_stack	*stack;
	int		size;

	size = 0;
	size = argc - 1;
	stack = malloc(sizeof(t_stack) * 1);
	if (!stack)
		return (1);
	stack->a = intializearray2(argv, size);
	if (!stack->a)
		return (free(stack), 1);
	stack->b = malloc(sizeof(int) * size);
	if (!stack->b)
		return (free(stack->a), free(stack), 1);
	stack->size_a = size;
	stack->size_b = 0;
	sort(stack);
	return (free(stack->a), free(stack->b), free(stack), 0);
}

int	main(int argc, char *argv[])
{
	if (argc < 2)
		return (0);
	if (argc == 2 && caseone(argv[1]))
		return (1);
	else if (casetwo(argv, argc))
		return (1);
	return (0);
}
