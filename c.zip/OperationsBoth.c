/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OperationsBoth.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 01:42:09 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:19:49 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ss(t_stack *stack)
{
	swap(stack->a, stack->size_a);
	swap(stack->b, stack->size_b);
	write(1, "ss\n", 3);
}

void	rr(t_stack *stack)
{
	rotate(stack->a, stack->size_a);
	rotate(stack->b, stack->size_b);
	write(1, "rr\n", 3);
}

void	rrr(t_stack *stack)
{
	reverse_rotate(stack->a, stack->size_a);
	reverse_rotate(stack->b, stack->size_b);
	write(1, "rrr\n", 4);
}
