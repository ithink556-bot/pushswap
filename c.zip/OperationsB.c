/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OperationsB.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 01:41:22 by invader           #+#    #+#             */
/*   Updated: 2025/10/21 02:17:20 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sb(t_stack *stack)
{
	swap(stack->b, stack->size_b);
	write(1, "sb\n", 3);
}

void	pb(t_stack *stack)
{
	push(stack->a, stack->b, &stack->size_a, &stack->size_b);
	write(1, "pb\n", 3);
}

void	rb(t_stack *stack)
{
	rotate(stack->b, stack->size_b);
	write(1, "rb\n", 3);
}

void	rrb(t_stack *stack)
{
	reverse_rotate(stack->b, stack->size_b);
	write(1, "rrb\n", 4);
}
