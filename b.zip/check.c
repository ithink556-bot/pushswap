/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 21:42:04 by invader           #+#    #+#             */
/*   Updated: 2025/10/10 18:25:06 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	checkmaxmin(long nb, int sign, int bool)
{
	if (nb > __LONG_MAX__ - 7)
	{
		bool = 1;
		return (1);
	}
	return (0);
}

long	ft_atol(char *str, int *bool)
{
	long	i;
	long	nb;
	int		sign;

	sign = 1;
	i = 0;
	nb = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		if (checkmaxmin(nb, sign, &bool))
			return (0);
		nb *= 10;
		nb += sign * (str[i] - '0');
		i++;
	}
	return (nb);
}
