/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 18:58:59 by invader           #+#    #+#             */
/*   Updated: 2025/10/10 18:21:29 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	caseone(char *str)
{
	t_stack	*stack;
	int		i;

	i = 0;
	stack = stackintialize(0);
	if (!stack)
		return (1);
	stack->a = arrayintialize(str);
	if (!stack->a)
		return (free(stack), 1);
	stack->b = arrayintialize(str);
	if (!stack->b)
		return (free(stack->a), free(stack), 1);
}

int	casetwo(char *argv[])
{
	t_stack	*stack;

	stack = stackintialize(0);
	if (!stack)
		return (1);
	stack->a = arrayintialize2(argv);
	if (!stack->a)
		return (free(stack), 1);
	stack->b = arrayintialize2(argv);
	if (!stack->b)
		return (free(stack->a), free(stack), 1);
}

int	main(int argc, char *argv[])
{
	if (argc < 2)
		return (0);
	if (argc == 2 && casetwo(argv[1]))
		return (1);
	else if (caseone(argv))
		return (1);
	return (0);
}
