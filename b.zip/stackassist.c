/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stackassist.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hasdia <hasdia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 21:52:04 by invader           #+#    #+#             */
/*   Updated: 2025/10/10 19:16:48 by hasdia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	countnumbers(char *str)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	while (str[i])
	{
		if (!isnum(str[i]) || !isspace(str[i]))
			return (-1);
		while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
			i++;
		if (str[i] == '+' || str[i] == '-')
			i++;
		if ((str[i]) >= '0' && str[i] <= '9')
			count++;
		while ((str[i]) >= '0' && str[i] <= '9')
			i++;
	}
}

t_stack	*stackintialize(int size)
{
	t_stack	*stack;

	stack = malloc(sizeof(t_stack));
	if (!stack)
	{
		write(2, "Error\n malloc fail", 19);
		return (NULL);
	}
	stack->a = malloc(sizeof(int) * size);
	if (!stack->a)
	{
		write(2, "Error\n malloc fail", 19);
		free(stack);
		return (NULL);
	}
	stack->b = malloc(sizeof(int) * size);
	if (!stack->b)
	{
		write(2, "Error\n malloc fail", 19);
		free(stack->a);
		free(stack);
		return (NULL);
	}
	return (stack);
}

int	*intializearray(char *str)
{
	int		i;
	int		j;
	int		size;
	int		*array;
	char	*temp;

	i = 0;
	j = 0;
	size = countnumbers(str);
	if (size < 0)
		return (NULL);
	array = malloc(sizeof(int) * (size));
	if (!array)
		return (NULL);
	while (str[i] != '/0')
	{
		if (!isnum(str[i]) || !isspace(str[i]))
			return (free(array), NULL);
		while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
			i++;
		temp = getnb(str + i, i);
		array[j++] = ft_atol(temp, size);
		i++;
	}
	return (array);
}
