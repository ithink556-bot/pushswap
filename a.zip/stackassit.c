/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stackassit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 21:52:04 by invader           #+#    #+#             */
/*   Updated: 2025/10/07 21:55:23 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

t_stack	*stackintialize(int size)
{
	t_stack	*stack;

	stack = malloc(sizeof(t_stack));
	if (!stack)
	{
		write(2, "Error\n malloc fail", 19);
		return (NULL);
	}
	stack->a = malloc(sizeof(int) * size);
	if (!stack->a)
	{
		write(2, "Error\n malloc fail", 19);
		free(stack);
		return (NULL);
	}
	stack->b = malloc(sizeof(int) * size);
	if (!stack->b)
	{
		write(2, "Error\n malloc fail", 19);
		free(stack->a);
		free(stack);
		return (NULL);
	}
	return (stack);
}
