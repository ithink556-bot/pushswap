/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: invader <invader@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/07 18:58:59 by invader           #+#    #+#             */
/*   Updated: 2025/10/10 15:44:55 by invader          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	caseone(char *str)
{
	t_stack	*stack;

	stack = stackintialize(0);
	if (!stack)
		return (0);
}

int	casetwo(char *argv[])
{
	t_stack	*stack;

	stack = stackintialize(0);
	if (!stack)
		return (0);
}

int	main(int argc, char *argv[])
{
	if (argc < 2)
		return (0);
	if (argc == 2 && casetwo(argv[1]))
		return (1);
	else if (caseone(argv))
		return (1);
	return (0);
}
